DMS Grid interactive review e422829

1. Extract this ZIP.
2. Open a terminal in the extracted dms-harness folder.
3. Run: node start.cjs --open
4. Open http://localhost:5180 if the browser does not open automatically.

Mac shortcut: launch-mac.command starts the server and opens your browser.
Node.js 20 or later is required. No npm install, ffmpeg, tenant connection or internet access is needed.
Includes 22 Contoso documents, List/Tile views, Fluent Personas/thumbnails and mock upload/download/edit/delete.
Graph photos remain deferred. Office/PDF cards use illustrative covers; stored images, PDF and text can be previewed.
First launch copies the sample data into data/. Your changes persist there.
Stop with Ctrl+C. Set DMS_HARNESS_PORT to choose another port.
This package uses port 5180 so it does not reuse an older development server on 5173.
