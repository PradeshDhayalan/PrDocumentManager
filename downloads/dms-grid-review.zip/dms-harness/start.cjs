const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { app, store } = require('./api/server.cjs');
if (!fs.existsSync(store.statePath)) store.reset();
const web = path.resolve(__dirname, 'web');
const port = Number(process.env.DMS_HARNESS_PORT || 5180);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg' };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (/^\/(api|__mock|mock-sharepoint)(\/|$)/.test(url.pathname)) return app(req, res);
  let name;
  try { name = decodeURIComponent(url.pathname); } catch { res.writeHead(400); return res.end(); }
  if (name === '/') name = '/index.html';
  const file = path.resolve(web, '.' + name);
  if (!file.startsWith(web + path.sep)) { res.writeHead(403); return res.end(); }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  const stream = fs.createReadStream(file);
  stream.on('error', () => res.destroy());
  stream.pipe(res);
});
server.on('error', error => { process.stderr.write(error.code === 'EADDRINUSE' ? 'Port is busy. Set DMS_HARNESS_PORT to another port.\n' : 'Harness server could not start.\n'); process.exitCode = 1; });
server.listen(port, '127.0.0.1', () => {
  const url = 'http://localhost:' + port + '/?review=e422829';
  process.stdout.write('DMS Grid review e422829: ' + url + '\n');
  if (process.platform === 'darwin' && process.argv.includes('--open')) require('node:child_process').spawn('open', [url], {stdio:'ignore'}).on('error', () => {});
});
